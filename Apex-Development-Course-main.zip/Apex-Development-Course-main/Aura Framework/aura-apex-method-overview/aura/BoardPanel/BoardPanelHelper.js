({
    helperMethod: function () {
    }
});
